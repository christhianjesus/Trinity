#AST

$as_tree = [
            ['AST', [], [
                         ['Program',    %w[functions instructions], []],
                         ['Function',   %w[indentifier parameters type instructions], []],
                         ['Parameter',  %w[type identifier], []],
                         ['Type',        %w[], [
                             ['Boolean',        %w[             ], []],
                             ['Number',         %w[             ], []],
                             ['Matrix',         %w[digit1 digit2], []]
                             ]],
                         ['Definition',  %w[type identifier expression], []],
                         ['Instruction', %w[], [
                             ['Block',          %w[definitions instructions], []],
                             ['Conditional',    %w[expression intructions1 instructions2], []],
                             ['For',            %w[identifier expression instructions], []],
                             ['While',          %w[expression instructions], []],
                             ['Print',          %w[printers], []],
                             ['Read',           %w[identifier], []],
                             ['Set',            %w[identifier expression], []],
                             ['SetMatrix',      %w[identifier expression1 expression2 expression3], []]
                             ]],
                         ['Expresion', %w[], [
                             ['Plus', %w[expression1 expression2], []],
                             ['Minus', %w[expression1 expression2], []],
                             ['Multiplication', %w[expression1 expression2], []],
                             ['Division', %w[expression1 expression2], []],
                             ['Remain', %w[expression1 expression2], []],
                             ['Div', %w[expression1 expression2], []],
                             ['Mod', %w[expression1 expression2], []],
                                              
                             ['PlusCross', %w[expression1 expression2], []],
                             ['MinusCross', %w[expression1 expression2], []],
                             ['MultiplicationCross', %w[expression1 expression2], []],
                             ['DivisionCross', %w[expression1 expression2], []],
                             ['RemainCross', %w[expression1 expression2], []],
                             ['DivCross', %w[expression1 expression2], []],
                             ['ModCross', %w[expression1 expression2], []],
                                              
                             ['Less', %w[expression1 expression2], []],
                             ['Greater', %w[expression1 expression2], []],
                             ['LessEqual', %w[expression1 expression2], []],
                             ['GreaterEqual', %w[expression1 expression2], []],
                             ['Equal', %w[expression1 expression2], []],
                             ['NotEqual', %w[expression1 expression2], []],
                             ['And', %w[expression1 expression2], []],
                             ['Or', %w[expression1 expression2], []],
                                              
                             ['Not', %w[expression], []],
                             ['Uminus', %w[expression], []],
                             ['Transpose', %w[expression], []],
                             ['MatrixEval', %w[expression1 expression2], []],
                             ['MatrixExpression', %w[expressions], []],
                             ['Digit', %w[digit], []],
                             ['Identifier', %w[identifier], []],
                                              
                             ['True', %w[], []],
                             ['False', %w[], []],
                             ['Invoke', %w[indentifier expressions], []]
                            ]]
                 ]]
           ]

def create_class(father, name, attr)

  newClass = Class::new(father) do

    class << self 
      attr_accessor :attr
    end
    
    @attr = attr
    @attr.each { |a| attr_accessor a }
    
    def initialize(*attr)
      @attr_value = [self.class.attr, attr].transpose
      @attr_value.each do |n, v|
        self.call(n + '=', v)
      end
    end
  end
  Object::const_set(name, newClass)
  return newClass
end

def create_tree(father,tree)
  tree.each do |name|
    n = create_class(father, name[0], name[1])
    create_tree(n, name[2])
  end
end

create_tree(Object,$as_tree)